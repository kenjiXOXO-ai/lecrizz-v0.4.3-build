# LecRizz v0.4.3 development preview

This is a native Android keyboard project, not a Play Store release. It has not been compiled or tested on a physical device in the current editing environment. Do not treat the source ZIP as a verified APK.

## Implemented in this source update

- Native Android app screens: branded startup splash with the LecRizz bird-ring spinner, welcome, keyboard setup guide, dashboard, Settings, and My Story. The splash ends after local preference initialization; it does not fake a progress percentage.
- Shared local preference store for the Ocean Breeze and Sunset Glow themes. Both app screens and the keyboard read the same saved theme.
- Persistent keyboard preferences for key height, key borders, vibration, key sound, and double-space period.
- Horizontal, scrollable keyboard toolbar in the agreed order: Rizz, Translate, Clipboard, Emoji, GIFs, More.
- Clipboard inserts the current text clipboard item at the cursor; Emoji opens a picker and inserts the selected emoji. More opens keyboard preferences, the app, or the system keyboard picker.
- Rizz demo ideas are explicitly labelled as demo content. A persistent local tone picker offers Smooth, Flirty, Funny, Sweet, Confident, and Mysterious variations. Each suggestion opens a preview with separate Copy and Insert-at-cursor actions; inserting never replaces the whole draft.
- Password and no-personalized-learning fields disable Rizz and Translate actions.
- Offline word suggestions use a small built-in dictionary; tapping a suggestion replaces only the current partial word before the cursor, while the close control returns to toolbar tools without changing the draft. This is basic local prediction, not a full language model.
- Enter-key presses show a brief bird animation.
- Smart Enter, number row, symbols, shift/caps lock, backspace repeat, key preview, auto-capitalization, and double-space punctuation are retained.
- Backend dashboard and heartbeat routes fail closed if their environment secrets are missing. Dashboard Basic Auth also has an in-memory per-IP failed-login limit for development; production still requires HTTPS and stronger deployment-level controls.
- Reusable loading spinner and skeleton helpers use theme-aware colors and respect Android animation settings. The spinner is used during startup initialization; skeleton blocks remain intentionally unwired because this build has no genuinely asynchronous dashboard content to skeletonize.
- GitHub Actions workflow builds a debug APK and uploads it as an artifact when changes are pushed to GitHub or the workflow is run manually.

## Still not connected

- Rizz is local demo text, not AI.
- Translation is not connected to a translation engine; the keyboard tells the user that it is unavailable and does not alter their text.
- GIF search is not connected to a provider.
- Language source/target preferences are saved locally, but selecting them does not translate text until a real translation engine is connected.
- User authentication, verified subscription entitlements, and Google Play Billing are not production-ready. Dashboard plan values are development metadata only.

Do not claim those features are complete until a real service is implemented, privacy implications are reviewed, and the behavior is tested.

## Build with GitHub Actions

The workflow at `.github/workflows/android-debug.yml` uses Java 17 and Gradle 8.9 to run `gradle --no-daemon assembleDebug` from the `android/` folder. After the workflow succeeds, download the `lecrizz-debug-apk` artifact from the Actions run. The APK must still be installed and tested on a physical Android device.

## Local build requirements

- JDK 17
- Android SDK platform 35 and a compatible Android build-tools package
- Gradle 8.9

From the repository root, run:

```sh
cd android
gradle --no-daemon assembleDebug
```

## Development dashboard

```sh
cd backend
npm install
DASHBOARD_PASSWORD='use-a-long-unique-password' HEARTBEAT_KEY='use-a-different-long-random-secret' npm start
```

Do not deploy the development dashboard publicly without HTTPS, proper access control, production-grade rate limiting, and a production review. Never commit real secrets, keystores, or `.env` files.
