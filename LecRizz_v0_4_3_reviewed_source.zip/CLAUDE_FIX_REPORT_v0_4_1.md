# LecRizz v0.4 -> v0.4.1 review and fixes

## What I could and could not do
- NOT done: Gradle build, APK, any on-device test. This environment has no Android SDK, no Gradle, no JDK compiler
  for Android and no internet. Nothing here has been compiled against the Android SDK or run on a phone.
- Done: full read of every source file; XML well-formedness check (all 9 XML files parse); `node --check backend/server.js` passes;
  a JDK 21 `javac` syntax pass over all Java files (no parse errors; the only remaining errors are "cannot find symbol /
  package android.* does not exist" because android.jar is absent, so type-checking against Android is UNVERIFIED).
- Next step for you: run the included GitHub Actions workflow (or `gradle assembleDebug` with JDK 17, Gradle 8.9, SDK 35) and send me the log.

## Fixes made (source only, unverified at runtime) - all in LecRizzImeService.java
1. Insert can no longer overwrite a selection. Rizz Insert, Clipboard and Emoji now go through insertAtCursor(): with a selection,
   the cursor is collapsed to the end of it first, so commitText cannot replace the selected text. Text before/after the cursor is never deleted.
2. Emoji picker was a 16-row vertical list that would run off the screen. It is now an 8-per-row grid.
3. Tool popups (Clipboard, Emoji, More) now open above the toolbar instead of dropping down over the keys.
4. Popups are tracked and dismissed on window hidden, input finished and service destroy, so none can be left on screen over another app.
5. Privacy: Rizz now reads at most 1 character each side of the cursor (was up to 1000 chars) just to check if the field is empty.
   Clipboard preview is truncated to 120 chars and hidden entirely in password / no-personalized-learning fields.
6. Rizz/Translate were setEnabled(false) in private fields, which swallowed taps so the explanatory toast never showed. They stay dimmed
   but tappable and now explain why they are off.

## Reviewed, no change needed (by reading only)
- Theme: LecRizzPrefs stores Ocean/Sunset; MainActivity and KeyboardSettingsActivity read it; the IME re-reads it in onStartInputView
  and rebuilds keys. Persistence and keyboard application look correct on paper; needs a device test.
- Backend: dashboard and heartbeat fail closed (503) without DASHBOARD_PASSWORD / HEARTBEAT_KEY; timing-safe comparison; no secrets in source;
  dashboard escapes output. Remaining: no login rate limit and Basic auth needs HTTPS in any real deployment.
- Translate, GIFs and Rizz AI are honestly labelled as not connected.

## Known remaining items
- No Gradle wrapper in the repo (CI installs Gradle 8.9; local builds need it installed).
- Splash screen/spinner and skeleton are not wired in (the v0.4 app opens straight to Welcome); no reduced-motion setting beyond Android's animator toggle.
- Popups use focusable windows inside the IME; confirm on a device that focus/typing is unaffected.
- No word prediction, no Enter-key bird animation, no tone selection yet.
- Suggestion-strip close button colour is set once at creation.


## Follow-up source update: v0.4.2 (not compiled)
- Added a persistent local Rizz tone preference: Smooth, Flirty, Funny, Sweet, Confident, and Mysterious. Tone selection updates the three local demo suggestions; it does not call an AI service.
- Updated app/version labels to 0.4.2-dev.
- This follow-up has not been compiled or device-tested; please run the included CI workflow before treating it as buildable.


## v0.4.2 review (Claude) - source review only, NOT built, NOT device-tested
Could not run the GitHub Actions workflow: this environment has no internet, GitHub access, Android SDK or Gradle.
No Android build log exists. `javac_syntax_check.log` is only a syntax-level JDK pass (it fails on missing android.* classes by design) and is NOT a build log.

Reviewed by reading:
- Tone persistence: tone is stored under RIZZ_TONE in the same SharedPreferences file via apply(); the keyboard reads it on every Rizz tap, so it should survive restarts.
- Long-press on Rizz opens the tone picker; a normal tap uses the saved tone. Both are blocked in password / private fields.
- Selection-safe insert, private-field checks and popup cleanup from v0.4.1 are unchanged and still in place.

Fixed in this pass:
1. Real layout bug (present since the v0.4 toolbar): showSuggestions/hideSuggestions toggled the inner toolbar row, not its fixed-height scroll container, which would leave an empty 48 dp band above the suggestions and make the keyboard taller. They now toggle the scroll container.
2. Tone picker now shows a check mark on the current tone and a clearer title; an unknown stored tone falls back to Smooth.
3. The Rizz preview card heading now names the tone (e.g. "Subtle · Flirty · demo idea").

Still unverified: that it compiles, theme appearance of the popups on a device, long-press behaviour inside the scrolling toolbar, and every item on the device checklist.


## v0.4.3 review (Claude) - source review only, NOT built, NOT device-tested
No Android SDK/Gradle/internet here, so the GitHub Actions build was not run. No build log exists; javac_syntax_check.log is syntax-level only.
Only the backend auth function was exercised, using mock request/response objects (not real Express or Socket.IO).

Fixed in this pass:
1. Word suggestions: no longer shown mid-word (choosing one would have duplicated the rest of the word, e.g. "hel|lo"), in email/URL/filter/number fields,
   or when the app sets NO_SUGGESTIONS. Cursor movement can no longer dismiss a Rizz suggestion strip; only word-prediction strips are auto-hidden.
2. Enter bird popup is skipped when Android animations are turned off.
3. Splash spinner now uses the selected theme colours (it was always Ocean).
4. Backend throttle: (a) dashboardAuth is also used by io.engine.use(), which receives raw Node responses without res.status/res.set/res.send,
   so it is rewritten with setHeader/statusCode/end (works for both); this is from my knowledge of Socket.IO, unverified against a live install.
   (b) Requests with no credentials (browser first request, reconnecting socket) no longer count as failures, which could lock the owner out by reloading.
   Mock test: 30 header-less requests stay 401; 10 wrong passwords -> 429 with Retry-After; correct password while locked -> 429.

Open items / caveats (not changed):
- Throttle keys on the socket address: behind a reverse proxy all users share one IP (one attacker could lock everyone out); use a proxy-level limit + HTTPS.
- Enter bird plays on every Enter press (not only Rizz/Translate loading) and is a popup above the key, not a replacement of the key visual.
- The splash's "initialization" is one SharedPreferences read, so it will flash for a moment; rotation restarts at Welcome (screen state is not saved).
- Default Target language is Tagalog; consider English or "choose" so nothing assumes the user's language.
- Dictionary is ~200 words, prefix match only, no ranking, no trailing space after choosing.
