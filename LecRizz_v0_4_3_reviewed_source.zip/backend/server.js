// LecRizz developer dashboard server (development only).
// Env vars:
//   PORT                 default 3000
//   DASHBOARD_PASSWORD   protects the dashboard + /api/users (HTTP basic auth, user "admin")
//   HEARTBEAT_KEY        shared secret the Android app sends in the x-lecrizz-key header
const express = require('express');
const http = require('http');
const crypto = require('crypto');
const path = require('path');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);               // no CORS: dashboard is same-origin
app.use(express.json({ limit: '4kb' }));

const PLANS = ['Free', 'Monthly', 'Yearly', 'Lifetime', 'Founder'];
const MAX_USERS = 5000;
const users = new Map();
const authAttempts = new Map();
const AUTH_WINDOW_MS = 15 * 60 * 1000;
const AUTH_MAX_ATTEMPTS = 10;

function safeEqual(a, b) {
  const x = Buffer.from(String(a)), y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

// Works for both Express responses and the raw Node responses Socket.IO's engine middleware receives
// (raw responses have no res.status()/res.set()/res.send()).
function deny(res, code, message, headers) {
  for (const k of Object.keys(headers || {})) res.setHeader(k, headers[k]);
  res.statusCode = code;
  res.end(message || '');
}

function dashboardAuth(req, res, next) {
  const pw = process.env.DASHBOARD_PASSWORD;
  // Fail closed: never accidentally expose dashboard/user metadata on a public interface.
  if (!pw) return deny(res, 503, 'Dashboard is locked: set DASHBOARD_PASSWORD first.');

  // In-memory per-IP throttling is a baseline for this development dashboard, not a
  // substitute for HTTPS, a reverse-proxy limit, or a production identity provider.
  // Behind a proxy every client shares the proxy's address; see the review notes.
  const ip = (req.socket && req.socket.remoteAddress) || 'unknown';
  const now = Date.now();
  let bucket = authAttempts.get(ip);
  if (bucket && now - bucket.startedAt >= AUTH_WINDOW_MS) { authAttempts.delete(ip); bucket = null; }
  if (bucket && bucket.failures >= AUTH_MAX_ATTEMPTS) {
    const retrySeconds = Math.max(1, Math.ceil((AUTH_WINDOW_MS - (now - bucket.startedAt)) / 1000));
    return deny(res, 429, 'Too many failed dashboard sign-in attempts. Try again later.', { 'Retry-After': String(retrySeconds) });
  }

  const h = req.headers.authorization || '';
  const [scheme, token] = h.split(' ');
  if (scheme === 'Basic' && token) {
    const decoded = Buffer.from(token, 'base64').toString();
    const colon = decoded.indexOf(':');
    const given = colon >= 0 ? decoded.slice(colon + 1) : '';
    if (safeEqual(given, pw)) { authAttempts.delete(ip); return next(); }
    // Only a wrong password that was actually submitted counts as a failed attempt.
    if (!bucket) bucket = { startedAt: now, failures: 0 };
    bucket.failures += 1;
    authAttempts.set(ip, bucket);
    if (bucket.failures >= AUTH_MAX_ATTEMPTS) {
      return deny(res, 429, 'Too many failed dashboard sign-in attempts. Try again later.', { 'Retry-After': String(Math.ceil(AUTH_WINDOW_MS / 1000)) });
    }
  }
  // No credentials sent (the browser's first request, or a reconnecting Socket.IO client) is not counted,
  // otherwise the owner could lock themselves out just by reloading the page.
  deny(res, 401, '', { 'WWW-Authenticate': 'Basic realm="LecRizz dashboard"' });
}
if (!process.env.DASHBOARD_PASSWORD) console.warn('DASHBOARD_PASSWORD missing: dashboard endpoints will fail closed with HTTP 503.');
if (!process.env.HEARTBEAT_KEY) console.warn('HEARTBEAT_KEY missing: heartbeat endpoint will fail closed with HTTP 503.');

const clip = (v, n, d) => (typeof v === 'string' && v.trim() ? v.trim().slice(0, n) : d);

app.post('/api/heartbeat', (req, res) => {
  const key = process.env.HEARTBEAT_KEY;
  if (!key) return res.status(503).json({ error: 'heartbeat endpoint is locked: set HEARTBEAT_KEY first' });
  if (!safeEqual(req.headers['x-lecrizz-key'] || '', key)) return res.status(401).json({ error: 'unauthorized' });
  const u = req.body || {};
  const userId = clip(u.userId, 64, '');
  if (!userId) return res.status(400).json({ error: 'userId required' });
  if (!users.has(userId) && users.size >= MAX_USERS) return res.status(429).json({ error: 'too many users' });
  // NOTE: plan is client-reported. Real premium status must come from Google Play Billing + server checks.
  const plan = PLANS.includes(u.plan) ? u.plan : 'Free';
  users.set(userId, { userId, name: clip(u.name, 40, 'User'), plan, device: clip(u.device, 40, 'Android'), lastSeen: Date.now() });
  io.emit('users', Array.from(users.values()));
  res.json({ ok: true });
});

app.use(dashboardAuth);
app.get('/api/users', (req, res) => res.json(Array.from(users.values())));
app.use(express.static(path.join(__dirname, '../dashboard/public')));
io.engine.use(dashboardAuth);                // also protects the live socket

setInterval(() => {
  const now = Date.now();
  for (const [ip, bucket] of authAttempts) if (now - bucket.startedAt >= AUTH_WINDOW_MS) authAttempts.delete(ip);
  for (const [id, u] of users) if (now - u.lastSeen > 120000) users.delete(id);
  io.emit('users', Array.from(users.values()));
}, 30000);

server.listen(process.env.PORT || 3000, () => console.log('LecRizz dashboard running on http://localhost:' + (process.env.PORT || 3000)));
