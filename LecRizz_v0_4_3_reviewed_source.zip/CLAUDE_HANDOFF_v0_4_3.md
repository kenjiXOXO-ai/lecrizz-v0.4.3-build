# LecRizz v0.4.3-dev — Claude review handoff

Please review the actual source in this archive independently. This is a source update, not a verified APK. Do not assume it compiles or behaves correctly until a real Android build and device test prove that.

## What changed from v0.4.2

1. **Startup splash:** `MainActivity` shows the LecRizz brand, logo, and `LecRizzSpinnerView` while the app warms its local preference store. It transitions as soon as initialization finishes; there is no fake percentage or artificial delay.
2. **Offline word suggestions:** `LecRizzImeService` includes a small local dictionary. As the user types a partial word, up to three matches appear. Selecting one replaces only the partial token immediately before the cursor; text after the cursor is not intentionally deleted. The X control returns to the toolbar without altering the draft. This is deliberately a basic local feature, not AI or a full predictive model.
3. **Enter-key bird animation:** pressing the Enter/action key shows a short, non-interactive bird popup animation. It should be checked on-device for clipping, timing, and popup lifecycle.
4. **Rizz tone in app Settings:** the same six tones (Smooth, Flirty, Funny, Sweet, Confident, Mysterious) can be selected in the app Settings as well as by long-pressing Rizz in the keyboard. The value is shared through `LecRizzPrefs.RIZZ_TONE`.
5. **Language preferences:** Settings now allows choosing and saving a source language (including Auto-detect) and target language. These are saved preferences only; translation remains disconnected and the UI explicitly says so.
6. **Backend login throttling:** dashboard Basic Auth has an in-memory per-IP limit of ten failed attempts per 15-minute window, with HTTP 429 and Retry-After when locked. This is only a development baseline; it is not production-grade security and resets when the process restarts.
7. **Version bump:** Android `versionCode` 6, `versionName` `0.4.3-dev`, and matching app labels.

## Please inspect carefully

- Compile the complete Android project using JDK 17, Gradle 8.9, Android SDK platform 35, and compatible build tools. Fix every build/resource/manifest error and report the exact command and result.
- Inspect the new splash threading/lifecycle. Confirm the initializer cannot update a destroyed Activity and that the spinner respects reduced-motion settings.
- Test predictions at the beginning, middle, and end of an existing draft; verify choosing a suggestion does not remove text after the cursor. Test backspace, punctuation, spaces, symbols, password fields, and no-personalized-learning fields.
- Test the Enter bird popup when pressing newline, Send, Search, Done, and when the keyboard is immediately hidden. Confirm no window leak, clipping, or accidental tap interception.
- Test that Rizz tone selected from app Settings is reflected by keyboard Rizz and that long-press changes persist across service restart.
- Test source/target language preferences persist across activity restart. Ensure no UI implies translation is already working.
- Check sound/vibration/key-height/key-border/double-space preferences, theme persistence, toolbar scrolling, popups, clipboard, emoji insertion, and cursor-safe Rizz insert.
- Review backend auth throttling for proxy/IP caveats, memory cleanup, bypasses, and compatibility with Socket.IO's authorization middleware. Recommend stronger production protections.
- Verify no secrets were added and dashboard/heartbeat remain fail-closed when required env vars are missing.

## Known intentional limitations

- Rizz output is local demo text, not AI.
- Translation engine is not connected. Source/target preferences only persist settings.
- GIF search is not connected to a provider.
- The local dictionary is intentionally small and does not learn from user text or send typed text anywhere.
- `SkeletonBlock` remains a reusable helper but is not attached to static screens; there is no genuinely asynchronous dashboard content to skeletonize yet.
- Production authentication, verified subscription entitlements, Google Play Billing, and release signing are not implemented.
- The current editing environment has no Android SDK or Gradle executable, so the app has **not** been compiled and no physical-device tests have been performed here.

## Desired response from Claude

Please return (1) a prioritized blocker list, (2) concrete file/line references, (3) corrections applied in source if needed, and (4) a clear separation between verified build/device results and source-only observations. Do not merely approve by inspection if a build can be run.
