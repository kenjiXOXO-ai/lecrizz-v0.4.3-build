# LecRizz v0.4.3-dev changelog

## Added
- Branded startup screen with theme-aware bird-ring spinner while local preferences initialize.
- Basic offline dictionary suggestions for partially typed words.
- Cursor-aware suggestion insertion that replaces only the partial token before the cursor and leaves text after the cursor in place.
- Close control for returning from suggestions to toolbar tools without changing the draft.
- Short bird animation when the Enter/action key is pressed.
- App Settings picker for the same six saved Rizz tones available from the keyboard's long-press picker.
- Persisted source and target language preferences, with honest copy that translation is not connected.
- In-memory failed-login throttling for the development dashboard's Basic Auth.

## Changed
- Development version updated to `0.4.3-dev` and Android version code to `6`.
- README and Claude handoff now distinguish implemented source features from service integrations and tests that remain outstanding.

## Still intentionally deferred
- Real AI-generated Rizz, translation engine, GIF provider integration.
- Production authentication, subscription verification / Google Play Billing, release signing and Play Store submission.
- Skeleton placeholders for static screens: they should only be wired when genuine asynchronous screen content exists.

## Validation performed in this environment
- Parsed all 9 Android XML files successfully.
- Parsed `backend/package.json` successfully.
- `node --check backend/server.js` passed.
- `javac` parser check reported no Java syntax errors, but compilation could not complete because this environment lacks Android SDK classes / `android.jar` and Gradle.
- No APK was produced. No emulator or physical-device test was run.
